//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RusHeb.rc
//
#define IDD_RUSHEB                      129
#define IDR_POPUP                       201
#define IDC_RUS                         1002
#define IDC_HEB                         1003
#define IDC_NEW                         1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
