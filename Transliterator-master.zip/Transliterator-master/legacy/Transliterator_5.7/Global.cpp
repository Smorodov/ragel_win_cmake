#include "stdafx.h"

CAppModule _Module;
Language g_Language;
LANGID	g_LangID;
const LANGID g_LangIDDefault=MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US);
Options g_Options;
Ignore g_Ignore;