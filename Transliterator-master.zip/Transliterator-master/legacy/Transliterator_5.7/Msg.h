#ifndef __MSG_H__
#define __MSG_H__

#define WM_APPLY (WM_USER+1)

#endif // __MSG_H__