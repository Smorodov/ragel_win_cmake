#ifndef __PROFILECHANGED_H__
#define __PROFILECHANGED_H__

class ProfileChanged
{
public:
	void NotifyProfileChanged()
	{
	}
};

#endif // __PROFILECHANGED_H__