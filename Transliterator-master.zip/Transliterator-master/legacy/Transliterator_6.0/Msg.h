#ifndef __MSG_H__
#define __MSG_H__

// Apply
#define UWM_APPLY				(WM_USER+5)
// Profile Name changed
#define UWM_PROFILENAME			(WM_USER+6)
// Profile changed
#define UWM_PROFILECHANGE		(WM_USER+7)
// Profile was changed
#define UWM_PROFILEUPDATE		(WM_USER+8)
// Copy profile
#define UWM_PROFILECOPYPROFILE	(WM_USER+9)
// Reset profile
#define UWM_PROFILERESET		(WM_USER+10)

#endif // __MSG_H__