//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Lang2Lang.rc
//
#define IDS_ABOUT                       1
#define IDS_ERROR                       2
#define IDE_RICHED20                    3
#define IDE_RICHED32                    4
#define IDD_KEYSPAGE                    4
#define IDS_OPTIONS                     5
#define IDE_REGKEY                      6
#define IDS_LANG2LANG                   7
#define IDR_LANG2LANG                   100
#define IDD_GENERALPAGE                 102
#define IDD_ABOUT                       103
#define IDD_HELP                        104
#define IDR_MENU1                       109
#define IDR_POPUP                       109
#define IDC_EDITFROM                    1001
#define IDC_EDITTO                      1002
#define IDC_EMAIL                       1003
#define IDC_SITE                        1004
#define IDC_ENGFROM                     1005
#define IDC_RUSFROM                     1006
#define IDC_ENGTO                       1007
#define IDC_RUSTO                       1008
#define IDC_HELPW                       1010
#define IDC_HELPC                       1011
#define IDC_FROM1                       1013
#define IDC_FROM2                       1014
#define IDC_FROM3                       1015
#define IDC_FROM4                       1016
#define IDC_FROM5                       1017
#define IDC_LANG2LANG                   1018
#define IDC_TO                          1021
#define IDC_TRANSLATIONNO               1022
#define IDC_TRANSLATIONHOTKEY           1023
#define IDC_HOTKEYTRANSLATE             1024
#define IDC_SHOWTRAYICON                1025
#define IDC_MINIMIZEMINIMIZE            1026
#define IDC_MINIMIZETOTRAY              1027
#define IDC_CLOSEEXIT                   1028
#define IDC_CLOSETOTRAY                 1029
#define IDM_ABOUT                       40003
#define IDM_EXIT                        40004
#define IDM_HELP                        40005
#define IDM_UNDOFROM                    40006
#define IDM_REDOFROM                    40007
#define IDM_CUTFROM                     40008
#define IDM_COPYFROM                    40009
#define IDM_PASTEFROM                   40010
#define IDM_SELECTALLFROM               40011
#define IDM_UNDOTO                      40012
#define IDM_REDOTO                      40013
#define IDM_CUTTO                       40014
#define IDM_COPYTO                      40015
#define IDM_PASTETO                     40016
#define IDM_SELECTALLTO                 40017
#define IDM_OPTIONS                     40019
#define IDM_SHOW                        40023
#define IDM_HIDE                        40024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40025
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
