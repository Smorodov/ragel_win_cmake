#include "stdafx.h"
#include "language.h"

// User4
void Language::Reset9(LangProfile& rProfile)
{
	rProfile.ResetUser();
	rProfile.m_strName+=L"4";
}