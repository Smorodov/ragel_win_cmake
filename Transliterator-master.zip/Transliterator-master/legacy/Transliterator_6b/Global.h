#ifndef __GLOBAL_H__
#define __GLOBAL_H__

extern CAppModule _Module;
extern LANGID	g_LangID;
extern const LANGID g_LangIDDefault;
extern Language g_Language;
extern IgnoreArray g_Ignore;

#endif // __GLOBAL_H__
