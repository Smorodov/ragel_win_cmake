#include "stdafx.h"
#include "language.h"

// User2
void Language::Reset7(LangProfile& rProfile)
{
	rProfile.ResetUser();
	rProfile.m_strName+=L"2";
}