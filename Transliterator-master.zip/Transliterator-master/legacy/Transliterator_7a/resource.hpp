//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Transliterator.rc
//
#define IDR_TRANSLITERATOR              128
#define IDD_PROFILE                     200
#define IDD_OPTIONS_GENERAL             201
#define IDD_OPTIONS_VIEW                202
#define IDD_OPTIONS_HOTKEYS             203
#define IDD_TOOLS_FILES_TRANSLATION     204
#define IDD_HELP_USAGE                  205
#define IDD_HELP_ABOUT                  206
#define IDC_RETOP                       1000
#define IDC_REBOTTOM                    1001
#define IDC_GRPTOP                      1002
#define IDC_GRPBOTTOM                   1003
#define IDC_GRPPART                     1004
#define IDC_CMBSAVETEXT                 1005
#define IDC_RELANGTOP                   1006
#define IDC_RELANGBOTTOM                1007
#define IDC_LBLLANGTOP                  1008
#define IDC_LBLLANGBOTTOM               1009
#define IDC_GRPSAVETEXT                 1010
#define IDC_GRPLANGUAGE                 1011
#define IDC_CMBLANGUAGE                 1012
#define IDC_CMBSTARTUP                  1013
#define IDC_GRPSTARTUP                  1014
#define IDC_BTNAPPLY                    1015
#define IDC_BTNRESTORE                  1016
#define IDC_GRPCONTROLS                 1018
#define IDC_GRPPLACEMENT                1019
#define IDC_CHKTASKBAR                  1020
#define IDC_CHKTRAY                     1021
#define IDC_CMBPLACEMENT                1022
#define IDC_CHKWRAPTEXT                 1023
#define IDC_CHKSCROLLTEXT               1024
#define IDC_CHKSWITCHCONTROLS           1025
#define ID_FILE_EXIT                    32774
#define ID_FILE_OPEN_TOP                32775
#define ID_FILE_OPEN_BOTTOM             32776
#define ID_FILE_SAVE_TOP                32777
#define ID_FILE_SAVE_BOTTOM             32778
#define ID_PROFILE_FIRST                32780
#define ID_PROFILE_LAST                 32799
#define ID_OPTIONS_GENERAL              32800
#define ID_OPTIONS_VIEW                 32801
#define ID_OPTIONS_HOTKEYS              32802
#define ID_TOOLS_FILES_TRANSLATION      32803
#define ID_HELP_USAGE                   32804
#define ID_HELP_ABOUT                   32805
#define ID_PROFILE_                     32806

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        207
#define _APS_NEXT_COMMAND_VALUE         32807
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           129
#endif
#endif
