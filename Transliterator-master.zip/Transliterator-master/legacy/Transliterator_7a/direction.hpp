#ifndef TRANSLITERATOR_DIRECTION_H
#define TRANSLITERATOR_DIRECTION_H

struct direction
{
    enum type
    {
        top_to_bottom,
        bottom_to_top
    };
};

#endif // TRANSLITERATOR_DIRECTION_H
