#include "stdafx.hpp"
#include "resource.hpp"
#include "help_about_page.hpp"
