#include "stdafx.hpp"

// Application Module
CAppModule _Module;
