#include "stdafx.hpp"
#include "resource.hpp"
#include "options_hotkeys_page.hpp"
