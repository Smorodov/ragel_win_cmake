#include "stdafx.hpp"
#include "resource.hpp"
#include "tools_files_translation_page.hpp"

LRESULT tools_files_translation_page::on_init_dialog(HWND /*wnd_focus*/, LPARAM /*lparam*/)
{
    page_impl_init();

    return 0;
}
