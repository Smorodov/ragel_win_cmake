#include "stdafx.hpp"
#include "resource.hpp"
#include "options_view_page.hpp"
