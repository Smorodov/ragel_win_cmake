#ifndef __GLOBAL_H__
#define __GLOBAL_H__

#include "Translit.h"
extern Translit _Translit;
#define _MAX_CHAR 6000

#endif // __GLOBAL_H__