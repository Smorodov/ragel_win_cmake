#include "StdAfx.h"
#include "Global.h"

Translit _Translit;
Options _Options;
CAppModule _Module;