#include "StdAfx.h"
#include "Global.h"

Translit _Translit;
CAppModule _Module;
Options _Options;
const LANGID _LangIDDefault=MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US);
LANGID _LangID;