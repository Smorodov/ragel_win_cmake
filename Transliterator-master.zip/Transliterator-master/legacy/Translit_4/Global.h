#ifndef __GLOBAL_H__
#define __GLOBAL_H__

#define _MAX_CHAR 6000

#include "Options.h"
extern Options _Options;

#include "Translit.h"
extern Translit _Translit;

#endif // __GLOBAL_H__