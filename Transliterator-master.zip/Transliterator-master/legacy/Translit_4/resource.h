//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Translit.rc
//
#define IDR_TRANSLIT                    101
#define IDD_ABOUT                       102
#define IDD_GENERALPAGE                 202
#define IDD_TRANSLATEFILES              203
#define IDD_LAYOUTPAGE                  204
#define IDD_HOTKEYSPAGE                 205
#define IDR_TRAYICON                    207
#define IDC_SENGPLACE                   1000
#define IDC_SRUSPLACE                   1001
#define IDC_SENGTEXT                    1002
#define IDC_SRUSTEXT                    1003
#define IDC_EMAIL                       1004
#define IDC_SITE                        1005
#define IDC_SABOUT                      1006
#define IDC_SABOUTTRANSLIT              1007
#define IDC_ENG                         1008
#define IDC_RUS                         1009
#define IDC_ENGFONT                     1010
#define IDC_RUSFONT                     1011
#define IDC_SSEPARATOR                  1012
#define IDC_CLOSEEXIT                   1013
#define IDC_CLOSETOTRAY                 1014
#define IDC_MINIMIZENORMAL              1015
#define IDC_MINIMIZETOTRAY              1016
#define IDC_LOADONSTARTUP               1017
#define IDC_SHOTKEYS                    1018
#define IDC_SAUTOTRANSLATION            1019
#define IDC_ACTION                      1020
#define IDC_HOTKEYTRANSLIT              1021
#define IDC_SCLOSE                      1022
#define IDC_SFONTS                      1023
#define IDC_SMINIMIZE                   1024
#define IDC_STRAYICON                   1025
#define IDC_SSTARTUP                    1026
#define IDC_TRAYICONSHOWN               1027
#define IDC_TRAYICONHIDDEN              1028
#define IDC_ENGTORUS                    1029
#define IDC_RUSTOENG                    1030
#define IDC_PATH                        1031
#define IDC_BROWSE                      1032
#define IDC_FILES                       1033
#define IDC_DIRECTORIES                 1034
#define IDC_SUBDIRECTORIES              1035
#define IDC_THISDIRECTORY               1036
#define IDC_NAME                        1037
#define IDC_ENTRY                       1038
#define IDC_MP3TAGS                     1039
#define IDC_TRANSLATE                   1040
#define IDC_CLOSE                       1041
#define IDC_SDIRECTION                  1042
#define IDC_SDIRECTORY                  1043
#define IDC_SPATH                       1044
#define IDC_SFILE                       1045
#define ID_SHOW                         1046
#define ID_HIDE                         1047
#define IDC_SACTION                     1048
#define IDC_SHOTKEY                     1049
#define ID_VIEW_LANGUAGE_ENGLISH        32791
#define ID_VIEW_LANGUAGE_RUSSIAN        32792
#define ID_EDIT_NOTRANSLATE_INSERT      32793
#define ID_EDIT_NOTRANSLATE_DELETE      32794
#define ID_VIEW_LAYOUT_WRAPTEXT         32795
#define ID_VIEW_LAYOUT_SCROLLTEXT       32796
#define ID_TOOLS_TRANSLATION            32797
#define ID_TOOLS_TRANSLATEFILES         32798
#define ID_TOOLS_OPTIONS                32799
#define ID_EDIT_COPY_RUSTOENG           32803
#define ID_EDIT_COPY_ENGTORUS           32804
#define ID_EDIT_TRANSLATE               32808
#define ID_Menu                         32809
#define IDS_ERROR                       62000
#define IDS_OPTIONS                     62001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        208
#define _APS_NEXT_COMMAND_VALUE         32812
#define _APS_NEXT_CONTROL_VALUE         1050
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
