![306995208](https://user-images.githubusercontent.com/580536/149656754-76af39a5-9e25-4f1d-bf9a-4691884fbb2c.jpg)
![400073976](https://user-images.githubusercontent.com/580536/149656761-32155888-e81d-4ad1-ab47-3306ac3a56aa.jpg)
![742407993](https://user-images.githubusercontent.com/580536/149656759-1939a481-1f2b-4d94-bcda-8458348d5f72.jpg)

# Преамбула

Программа была выложена давно и с тех пор не поддерживается.  
Ищу желающих поддержать.
Возможно смена лицензии.

[Скачать](https://github.com/NN---/Transliterator/releases)

# Preface

The application has been developed long time ago and isn't maintained since then.  
Looking for a maintainer.
The license can be changed.

[Download](https://github.com/NN---/Transliterator/releases)

# Транслитерация текста

Перевод в обоих направлениях направлениях (translit в русский, русский в translit).

## Различные профили транслитерации:

* translit  >  русский
* русский  >  translit
* qwerty  >  йцукен
* йцукен  >  qwerty
* Русский  >  CuMBo/\bHblu`
* CuMBo/\bHblu`  >  Русский
* Cyrillic Windows  >  DOS 866
* DOS 866  >  Cyrillic Windows
* Cyrillic Windows  >  KOI8-R
* KOI8-R  >  Cyrillic Windows
* Пользовательский  >  Пользовательский

## Другие возможности

*  Символы игнорирования перевода (после установки такого символа, указанная часть текста не транслитеруются).

* Игнорируемый текст (этот текст не будет транлситироваться).

* Вызов программы с помощью горячей клавиши: показ/скрытие, автоматическая транслитерация.

* Возможность Транслитерации файлов (название файла или папки, содержание текста, MP3 тэги)

* Возможность изменения параметров транслитерации (символов перевода, игнорирования), профилей транслитерации и горячих клавиш на свой вкус.

* Сворачивание в иконку , а также настройки показа и скрытия иконки в системной панели.

* Языки интерфейса: English, Русский и Translit

## Минимальные требования:

Windows (95 / 98 / ME / 2000 / XP) и RichEdit версии 3.0 (входит в состав
Internet Explorer 5.0 и выше) 
